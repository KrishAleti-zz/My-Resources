from django.shortcuts import render, HttpResponse
from django.http import HttpResponse
# from . import models
from .models import Destination


# Create your views here.

# def index(request):
#     return render (request, 'index.html',{'discount':'10%'})

def index(request):

    dests = Destination.objects.all() 
    #we are getting all the data from the database and storing it in a 'dests' variable.
    
    return render(request, 'index.html', {'dests': dests,'discount':'10%'})
