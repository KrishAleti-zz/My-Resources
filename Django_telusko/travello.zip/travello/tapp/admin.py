from django.contrib import admin
from .models import Destination  #  importing the class or model
# Register your models here.


#  here we need to register the model and automatically it we create a page for us.
admin.site.register(Destination)  #need to give th model name here