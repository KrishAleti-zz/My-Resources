from django.db import models

# Create your models here.
#  Models are used to connect with databases and data.

class Destination(models.Model): #we are inheritng the feature of models.
     # https://docs.djangoproject.com/en/4.0/ref/models/fields/#autofield
    name = models.CharField(max_length=100)  
    img = models.ImageField(upload_to='pics') #basically we upload the images to a specific folder amd we need to give that folder name here.
    desc = models.TextField()  
    price = models.IntegerField()
    offer = models.BooleanField(default=False)